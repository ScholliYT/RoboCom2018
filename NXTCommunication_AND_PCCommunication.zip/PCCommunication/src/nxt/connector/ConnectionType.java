package nxt.connector;

public enum ConnectionType{
	
	USB,
	BLUETOOTH;
	
}